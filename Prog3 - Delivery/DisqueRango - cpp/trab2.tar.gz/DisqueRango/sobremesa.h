#include <string>
#include "cardapio.h"
#ifndef SOBREMESA_H_
#define SOBREMESA_H_

using namespace std;

class sobremesa : public cardapio{
	string tipo;
	bool quente;
	
public:
  sobremesa();
  sobremesa(int c,string t, string i, float p);
  
  ~sobremesa();
};

#endif //SOBREMESA_H_