#include <string>
#include <iostream>
#include <cstdlib>

#ifndef ERRO_H_
#define ERRO_H_
class erro{
public:
	erro();
	erro (char* args1,char* args2);
};

#endif //ERRO_H_