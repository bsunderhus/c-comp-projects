#include <stdio.h>
#include <stdlib.h>


int main(int argc, char* argv[])
{
 if(argc != 3)
 {
  fprintf(stderr, "Usage: %s processes\n", argv[0]);
  return 1;
 }
 
 int sleepTime = atoi(argv[1]);
 int repeatFactor = atoi(argv[2]);
 int i = 0;
 
 
 while ( i < repeatFactor)
 {
   sleep(sleepTime);
   fprintf(stderr,"%d\n\n",getpid());
   i++;
 }
  return 0;
}